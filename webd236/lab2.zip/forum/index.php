<?php
include_once 'include/util.inc';
redirect("index");
?>