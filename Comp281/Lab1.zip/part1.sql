set echo on;
set serveroutput on;
select * from user_role_privs;
select * from crawforl.customer;
desc tabs;
show user;